"""NXL protocol resources."""
