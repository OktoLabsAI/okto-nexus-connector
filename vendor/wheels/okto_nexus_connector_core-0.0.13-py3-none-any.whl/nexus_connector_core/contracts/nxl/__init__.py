"""NXL protocol resources."""
